@extends('layouts.app')

@section('title', 'Candidate Assignment')

@section('content')
    <h3>{{ $time }}</h3>
@endsection
